package com.example.springbootfileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootfileuploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootfileuploadApplication.class, args);
	}

}
